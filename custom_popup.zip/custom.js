        jQuery(document).ready(function(){
            jQuery(".inline").colorbox({inline:true, width:"50%"});
        });